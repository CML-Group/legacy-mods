## 5001_queenbee01_draw 02 - 去除部分衣服 + 身体更改 + 胸部更改 + 脸红 + 淫纹

![](./5001_queenbee01_draw_02.png)

> 去除部分衣服 | 身体更改(R18) | 胸部更改(R18) | 脸红 | 淫纹(R18)

#MOD #女王蜂 #默认立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/5001_queenbee01_draw_02.zip)**