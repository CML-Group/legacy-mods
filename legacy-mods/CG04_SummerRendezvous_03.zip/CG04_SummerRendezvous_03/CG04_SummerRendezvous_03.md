## CG04_SummerRendezvous 03 - 身体更改 + 胸部更改

<video autoplay loop>
  <source src="./CG04_SummerRendezvous_03.mp4" type="video/mp4">
</video>

> 身体更改(R18) | 胸部更改(R18)

*<font color="#FFFFFF">~~有瑕疵 请等待修复版本~~</font>*

#MOD #热夏之约 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG04_SummerRendezvous_03.zip)**