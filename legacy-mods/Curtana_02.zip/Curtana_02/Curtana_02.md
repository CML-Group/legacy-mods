## Curtana 02 - 胸部更改

<video autoplay loop>
  <source src="./Curtana_02.mp4" type="video/mp4">
</video> 

> 胸部更改(R18)

#MOD #卡提那 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Curtana_02.zip)**