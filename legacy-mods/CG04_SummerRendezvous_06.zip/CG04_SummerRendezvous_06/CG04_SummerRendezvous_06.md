## CG04_SummerRendezvous 06 - 身体更改 + 胸部更改

<video autoplay loop>
  <source src="./CG04_SummerRendezvous_06.mp4" type="video/mp4">
</video>

> 身体更改(R18) | 胸部更改(R18)

*"那个半透衣服旋律内裤有点黑不好看，荧的泳裤有黑边，所以我把他两~~优点~~'合'一起了。<font color="#FFFFFF">女王蜂我直接把他拉边上了，所以没改。</font>"*

*依据[此立绘](#cg04-summerrendezvous-07-身体更改)和[此立绘](#cg04-summerrendezvous-03-身体更改-胸部更改)更改*

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #热夏之约 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG04_SummerRendezvous_06.zip)**