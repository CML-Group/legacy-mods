## Anthem 01 - 胸部更改

<video autoplay loop>
  <source src="./Anthem_01.mp4" type="video/mp4">
</video>

> 胸部更改(乳环/R18)

#MOD #圣歌 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Anthem_01.zip)**