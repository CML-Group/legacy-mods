## CG05_ShimmeringFeast 02 - 胸部更改

<video autoplay loop>
  <source src="./CG05_ShimmeringFeast_02.mp4" type="video/mp4">
</video>

> 胸部更改(x2/R18)

#MOD #曦光盛宴 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG05_ShimmeringFeast_02.zip)**