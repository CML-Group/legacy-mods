## Noctilucent 06 - 新年快乐

<video autoplay loop>
  <source src="./Noctilucent_06.mp4" type="video/mp4">
</video>

> 新年快乐

via [Yukinwo](https://www.pixiv.net/users/19157128)

#MOD #荧 #突破动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Noctilucent_06.zip)**