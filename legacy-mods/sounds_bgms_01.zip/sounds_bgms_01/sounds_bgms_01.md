## sounds_bgms 01 - 套用第三方音频资源

<audio controls>
  <source src="./sounds_bgms_01.ogg" type="audio/ogg">
</audio>

> 套用第三方音频资源

via [AhAlpha](https://t.me/ahofcl)

#MOD #音乐 #背景音乐

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/sounds_bgms_01.zip)**