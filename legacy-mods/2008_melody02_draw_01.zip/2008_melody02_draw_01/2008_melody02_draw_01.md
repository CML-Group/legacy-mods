## 2008_melody02_draw 01 - 淫纹

![](./2008_melody02_draw_01.png)

> 淫纹(R18)

*可考虑配合[此资源](../animated/#melody-03-淫纹)一起使用*

#MOD #旋律 #突破立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/2008_melody02_draw_01.zip)**