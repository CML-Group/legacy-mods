## Capriccio 01 - 身体更改

<video autoplay loop>
  <source src="./Capriccio_01.mp4" type="video/mp4">
</video>

> 身体更改(R18)

via [我不是三三](#暂无此作者的相关链接)

#MOD #随想曲 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Capriccio_01.zip)**