## Aurora 02 - 胸部更改

<video autoplay loop>
  <source src="./Aurora_02.mp4" type="video/mp4">
</video> 

> 胸部更改(R18)

*根据[此立绘](#aurora-01-胸部更改)重新调色*

via [喵提不起劲 本](#暂无此作者的相关链接)

#MOD #极光 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Aurora_02.zip)**