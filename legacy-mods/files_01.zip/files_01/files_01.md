## files 01 - 套用第三方图像资源

![](./files_01.png)

> 套用第三方图像资源

via [AhAlpha](http://t.me/ahofcl)

#MOD #其他 #公告图