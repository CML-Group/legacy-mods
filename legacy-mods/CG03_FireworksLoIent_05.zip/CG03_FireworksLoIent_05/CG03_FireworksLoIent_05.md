## CG03_FireworksLoIent 05 - 去除部分裙子 + 胸部更改 + 身体更改 + 环

<video autoplay loop>
  <source src="./CG03_FireworksLoIent_05.mp4" type="video/mp4">
</video>

> 去除部分裙子(R18) | 胸部更改(R18) | 身体更改(R18) | 环(R18)

*在[上一次小改](#cg03-fireworksloient-04-去除部分裙子-胸部更改-身体更改-环)的基础上修复了大量"已知问题"*

*依据[此立绘](#cg03-fireworksloient-03-去除部分裙-胸部更改-身体更改)更改*

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #顷刻烟火 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG03_FireworksLoIent_05.zip)**