## 4031_noctilucent01_draw 01 - 裸足

![](./4031_noctilucent01_draw_01.png)

> 裸足

#MOD #荧 #默认立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/4031_noctilucent01_draw_01.zip)**