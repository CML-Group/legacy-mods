## Hades_Death 04 - 胸部更改

<video autoplay loop>
  <source src="./Hades_Death_04.mp4" type="video/mp4">
</video> 

> 胸部更改(R18)

*不许说哈迪斯是男娘 （*

*我已经给她丰胸过了  ）*

via [Yukinwo](https://www.pixiv.net/users/19157128)

#MOD #哈迪斯 #形态切换动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Hades_Death_04.zip)**