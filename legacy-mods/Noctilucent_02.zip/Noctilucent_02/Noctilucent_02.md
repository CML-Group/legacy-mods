## Noctilucent 02 - 衣服更改

<video autoplay loop>
  <source src="./Noctilucent_02.mp4" type="video/mp4">
</video>

> 衣服更改(透明)

#MOD #荧 #突破动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Noctilucent_02.zip)**