## CG03_FireworksLoIent 03 - 去除部分裙 + 胸部更改 + 身体更改

<video autoplay loop>
  <source src="./CG03_FireworksLoIent_03.mp4" type="video/mp4">
</video>

> 去去除部分裙子(R18) | 胸部更改(<font color="#FFFFFF">乳环</font>/R18) | 身体更改(<font color="#FFFFFF">"节育环"😅</font>/R18)

#MOD #顷刻烟火 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG03_FireworksLoIent_03.zip)**