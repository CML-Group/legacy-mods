## 20240_break_Uillean_spine 08 - 去除部分小部件 + 胸部更改 + 腿部更改

<video autoplay loop>
  <source src="./20240_break_Uillean_spine_08.mp4" type="video/mp4">
</video>

> 去除部分小部件 | 胸部更改(单乳/R18) | 腿部更改

*"都是卸了部分配件，有部分重画了，部分需要大改的没弄，反正不是皮肤"*

*依据[此立绘](#_20240-break-uillean-spine-03-腿部更改)与[此立绘](#_20240-break-uillean-spine-02-胸部更改)更改*

artist [朝雾星弦](https://space.bilibili.com/6751172)

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #乌琳 #突破动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/20240_break_Uillean_spine_08.zip)**