## 4031_noctilucent03_draw 02 - 去和谐 + 去除更多衣 + 身体更改

![](./4031_noctilucent03_draw_02.png)

> 去和谐(光) | 去除更多衣服(R18) | 身体更改(R18)

*"静态图 MVP结算图 升级图 小队队长图"*

*依据[此立绘](../animated/#_40310-skin-noctilucent03-spine-06-去和谐-去除更多衣服-身体更改)更改*

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #荧 #限定立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/4031_noctilucent03_draw_02.zip)**