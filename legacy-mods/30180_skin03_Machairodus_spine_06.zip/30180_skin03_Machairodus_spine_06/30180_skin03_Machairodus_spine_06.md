## 30180_skin03_Machairodus_spine 06 - 去路障

<video autoplay loop>
  <source src="./30180_skin03_Machairodus_spine_06.mp4" type="video/mp4">
</video>

> 去路障

*修复了之前去路障一直残留的阴影问题。*

#MOD #刃齿 #限定动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/30180_skin03_Machairodus_spine_06.zip)**