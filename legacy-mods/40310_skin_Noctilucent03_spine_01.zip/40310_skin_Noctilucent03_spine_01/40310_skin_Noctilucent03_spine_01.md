## 40310_skin_Noctilucent03_spine 01 - 去和谐

<video autoplay loop>
  <source src="./40310_skin_Noctilucent03_spine_01.mp4" type="video/mp4">
</video>

> 去和谐(光)

#MOD #荧 #限定动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/40310_skin_Noctilucent03_spine_01.zip)**