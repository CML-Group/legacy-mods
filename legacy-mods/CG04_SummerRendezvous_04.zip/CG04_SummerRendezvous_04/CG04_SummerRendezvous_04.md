## CG04_SummerRendezvous 04 - 去和谐 + 一些改动

<video autoplay loop>
  <source src="./CG04_SummerRendezvous_04.mp4" type="video/mp4">
</video>

> 去和谐(R18) | 一些改动(修复大腿衔接)

#MOD #热夏之约 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG04_SummerRendezvous_04.zip)**