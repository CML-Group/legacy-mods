## 10030_skin_Wolframite03_spine 01 - 去除部分衣服

<video autoplay loop>
  <source src="./10030_skin_Wolframite03_spine_01.mp4" type="video/mp4">
</video>

> 去除部分衣服

#MOD #钨铬 #限定动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/10030_skin_Wolframite03_spine_01.zip)**