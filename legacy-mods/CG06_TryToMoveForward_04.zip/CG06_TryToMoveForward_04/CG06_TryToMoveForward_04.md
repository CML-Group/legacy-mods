## CG06_TryToMoveForward 04 - 去除更多衣服 + 衣服破损 + 身体更改

<video autoplay loop>
  <source src="./CG06_TryToMoveForward_04.mp4" type="video/mp4">
</video>

> 去除更多衣服(R18) | 衣服破损 | 身体更改(R18)

via [Yukinwo](https://www.pixiv.net/users/19157128)

#MOD #导购进修课 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG06_TryToMoveForward_04.zip)**