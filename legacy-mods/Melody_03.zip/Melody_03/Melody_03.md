## Melody 03 - 淫纹

<video autoplay loop>
  <source src="./Melody_03.mp4" type="video/mp4">
</video>

> 淫纹(R18)

*可考虑配合[此资源](../static/#_2008-melody02-draw-01-淫纹)一起使用*

#MOD #旋律 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Melody_03.zip)**