## 20240_break_Uillean_spine 03 - 腿部更改

<video autoplay loop>
  <source src="./20240_break_Uillean_spine_03.mp4" type="video/mp4">
</video>

> 腿部更改

```
更新日志
1/22 -- 修复武器偏移与效果缺失
1/27 -- 初步修复右腿衔接 (鸣谢 knu vin) 
```

artist [朝雾星弦](https://space.bilibili.com/6751172)

via [AhAlpha](https://t.me/ahofcl)

#MOD #乌琳 #突破动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/20240_break_Uillean_spine_03.zip)**