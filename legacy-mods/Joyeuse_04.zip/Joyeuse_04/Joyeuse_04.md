## Joyeuse 04 - 去除部分衣服 + 胸部更改

<video autoplay loop>
  <source src="./Joyeuse_04.mp4" type="video/mp4">
</video> 

> 去除部分衣服 | 胸部更改(R18)

*相比[上一次的作品](#joyeuse-02-去除部分衣服-胸部更改) 对身体进行重调色 (鸣谢 [快看她手上有喵粮](#暂无此作者的相关链接))*

via [Yukinwo](https://www.pixiv.net/users/19157128)

#MOD #咎瓦尤斯 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Joyeuse_04.zip)**