## Hades_Death 03 - 胸部更改

<video autoplay loop>
  <source src="./Hades_Death_03.mp4" type="video/mp4">
</video> 

> 胸部更改(R18)

*仅半成品*

*根据[此立绘](#hades-death-01-胸部更改)更改*

via [AhAlpha](https://t.me/ahofcl)

#MOD #哈迪斯 #形态切换动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Hades_Death_03.zip)**