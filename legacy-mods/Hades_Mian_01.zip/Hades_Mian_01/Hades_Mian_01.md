## Hades_Mian 01 - 胸部更改

<video autoplay loop>
  <source src="./Hades_Mian_01.mp4" type="video/mp4">
</video> 

> 胸部更改(R18)

via [JianY](https://t.me/Archetto_t)

#MOD #哈迪斯 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Hades_Mian_01.zip)**