## CG03_FireworksLoIent 01 - 去除部分裙子

<video autoplay loop>
  <source src="./CG03_FireworksLoIent_01.mp4" type="video/mp4">
</video>

> 去除部分裙子(R18)

#MOD #顷刻烟火 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG03_FireworksLoIent_01.zip)**