## 30080_skin_Talbot03_spine 02 - 去除部分衣服 + 胸部更改 + 衣服破损 + 在身上计数 + 眼罩

<video autoplay loop>
  <source src="./30080_skin_Talbot03_spine_02.mp4" type="video/mp4">
</video>

> 去除部分衣服 | 胸部更改(R18) | 衣服破损 | 在身上计数(R18) | 眼罩

#MOD #塔尔博特 #限定动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/30080_skin_Talbot03_spine_02.zip)**