## multiimg_fireworks_ioient 01 - 去除部分裙子 + 胸部更改

![](./multiimg_fireworks_ioient_01.png)

> 去除部分裙子(R18) | 胸部更改(R18)

*<font color="#FFFFFF">与</font>[<font color="#FFFFFF">上一个顷刻烟火</font>](../animated/#cg03-fireworksloient-02-去除部分裙子-胸部更改)<font color="#FFFFFF">相比 更改了荧的胸部</font>*

#MOD #顷刻烟火 #静态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/multiimg_fireworks_ioient_01.zip)**