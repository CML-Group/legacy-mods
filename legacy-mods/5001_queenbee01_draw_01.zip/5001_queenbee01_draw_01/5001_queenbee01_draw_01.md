## 5001_queenbee01_draw 01 - 半透明衣服 + 身体更改 + 脸红 + 淫纹

![](./5001_queenbee01_draw_01.png)

> 半透明衣服 | 身体更改(R18) | 脸红 | 淫纹

#MOD #女王蜂 #默认立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/5001_queenbee01_draw_01.zip)**