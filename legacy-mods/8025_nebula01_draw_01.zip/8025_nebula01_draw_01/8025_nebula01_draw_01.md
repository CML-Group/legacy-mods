## 8025_nebula01_draw 01 - 拟人化

![](./8025_nebula01_draw_01.png)

> 拟人化

via [Yukinwo](https://www.pixiv.net/users/19157128)

#MOD #荧 #星云 #默认立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/8025_nebula01_draw_01.zip)**