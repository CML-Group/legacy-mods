## 30431_Synchro_Lepus 01 - 去除部分衣服

<video autoplay loop>
  <source src="./30431_Synchro_Lepus_01.mp4" type="video/mp4">
</video> 

> 去除部分衣服

#MOD #莉普丝 #突破动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/30431_Synchro_Lepus_01.zip)**