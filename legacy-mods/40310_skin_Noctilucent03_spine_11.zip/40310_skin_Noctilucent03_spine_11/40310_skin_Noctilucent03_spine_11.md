## 40310_skin_Noctilucent03_spine 11 - 去和谐 + 去除更多衣服 + 去除部分小部件 + 身体更改

<video autoplay loop>
  <source src="./40310_skin_Noctilucent03_spine_11.mp4" type="video/mp4">
</video>

> 去和谐(光) | 去除更多衣服(R18) | 去除部分小部件 | 身体更改(R18)

*"这游戏模型精度真的低,，唉，估计作者自己把精度调高了，原版黑丝的话屁股好看点，因为黑的也看不清"*

*依据[此立绘](#_40310-skin-noctilucent03-spine-06-去和谐-去除更多衣服-身体更改)更改*

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #荧 #限定动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/40310_skin_Noctilucent03_spine_11.zip)**