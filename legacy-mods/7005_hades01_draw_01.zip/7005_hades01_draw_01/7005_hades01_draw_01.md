## 7005_hades01_draw 01 - 胸部更改 + 身体更改

![](./7005_hades01_draw_01.png)

> 胸部更改(R18) | 身体更改(R18)

via [JianY](https://t.me/Archetto_t)

#MOD #哈迪斯 #默认立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/7005_hades01_draw_01.zip)**