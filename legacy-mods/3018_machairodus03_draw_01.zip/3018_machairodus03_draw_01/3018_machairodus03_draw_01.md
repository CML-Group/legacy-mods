## 3018_machairodus03_draw 01 - 去除部分衣服 + 身体更改 + 身上有字 + 在身上计数 + 插入物 + 跳蛋

![](./3018_machairodus03_draw_01.png)

> 去除部分衣服 | 身体更改(R18) | 身上有字(R18) | 在身上计数(R18) | 插入物(R18) | 跳蛋(R18)

*"荧和刃齿那两个魔改不是只魔改动图么，结算界面和升级界面他们还是原来的版本，所以我把魔改的图截进去了，这样升级界面和结算界面也是魔改版本的"*

*依据[此立绘](../animated/#_30180-skin03-machairodus-spine-05-去除部分衣服-身体更改-身上有字-在身上计数-插入物-跳蛋)更改*

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #刃齿 #限定立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/3018_machairodus03_draw_01.zip)**