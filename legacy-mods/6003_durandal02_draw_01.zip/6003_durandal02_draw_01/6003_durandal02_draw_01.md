## 6003_durandal02_draw 01 - 套用限定立绘

![](./6003_durandal02_draw_01.png)

*"娱乐"*

> 套用第三方立绘

artist [`Dκ. Senie`](https://twitter.com/dk_senie/status/1713408667192868910)

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #赤狼 #突破立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/6003_durandal02_draw_01.zip)**