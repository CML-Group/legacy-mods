## 10030_skin_Wolframite03_spine 02 - 衣服更改 + 胸部更改

<video autoplay loop>
  <source src="./10030_skin_Wolframite03_spine_02.mp4" type="video/mp4">
</video>

> 衣服更改 | 胸部更改(R18)

#MOD #钨铬 #限定动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/10030_skin_Wolframite03_spine_02.zip)**