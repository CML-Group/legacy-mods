## 20080_skin_melody03_spine 01 - 去除部分衣服 + 胸部更改

<video autoplay loop>
  <source src="./20080_skin_melody03_spine_01.mp4" type="video/mp4">
</video>

> 去除部分衣服 | 胸部更改(R18)

*仅半成品*

via [AhAlpha](https://t.me/ahofcl)

#MOD #旋律 #限定动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/20080_skin_melody03_spine_01.zip)**