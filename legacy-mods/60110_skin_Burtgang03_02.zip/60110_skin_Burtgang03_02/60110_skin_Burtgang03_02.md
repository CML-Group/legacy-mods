## 60110_skin_Burtgang03 02 - 衣服更改 + 胸部更改 + 液体

<video autoplay loop>
  <source src="./60110_skin_Burtgang03_02.mp4" type="video/mp4">
</video> 

> 衣服更改 | 胸部更改(R18) | 液体(酒杯/R18)

via [Saika Senya](#暂无此作者的相关链接)

#MOD #布尔特根 #限定动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/60110_skin_Burtgang03_02.zip)**