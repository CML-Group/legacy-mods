## Hades_Death 01 - 胸部更改

<video autoplay loop>
  <source src="./Hades_Death_01.mp4" type="video/mp4">
</video> 

> 胸部更改(R18)

*哈迪斯这么小，我也比较习惯尊重原设定，衣服图层下面没几个图层，可以折腾的地方不多索性研究动画了，已经理解如何修改与实现了，后续再折腾吧。*

via [Yukinwo](https://www.pixiv.net/users/19157128)

#MOD #哈迪斯 #形态切换动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Hades_Death_01.zip)**