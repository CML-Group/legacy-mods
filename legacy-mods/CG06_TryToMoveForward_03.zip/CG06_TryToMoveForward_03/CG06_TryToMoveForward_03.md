## CG06_TryToMoveForward 03 - 去除更多衣服

<video autoplay loop>
  <source src="./CG06_TryToMoveForward_03.mp4" type="video/mp4">
</video>

> 去除更多衣服(R18)

#MOD #导购进修课 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG06_TryToMoveForward_03.zip)**