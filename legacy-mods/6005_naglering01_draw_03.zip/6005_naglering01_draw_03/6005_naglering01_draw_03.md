## 6005_naglering01_draw 03 - 去除部分衣服 + 身体更改

![](./6005_naglering01_draw_03.png)

> 去除部分衣服 | 身体更改(R18)

*依据[此立绘](#_6005-naglering01-draw-01-去除部分衣服-身体更改-瞳孔-避孕套)更改*

via [雒邪](#暂无此作者的相关链接)

#MOD #纳格陵 #默认立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/6005_naglering01_draw_03.zip)**