## 6005_naglering01_draw 01 - 去除部分衣服 + 身体更改 + 瞳孔 + 避孕套

![](./6005_naglering01_draw_01.png)

> 去除部分衣服 | 身体更改(R18) | 瞳孔(R18) | 避孕套(R18)

#MOD #纳格陵 #默认立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/6005_naglering01_draw_01.zip)**