## Curtana 06 - 去除部分小部件 + 胸部更改

<video autoplay loop>
  <source src="./Curtana_06.mp4" type="video/mp4">
</video> 

> 去除部分小部件 | 胸部更改(R18)

*依据[此立绘](#curtana-05-胸部更改)更改*

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #卡提那 #突破动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/Curtana_06.zip)**