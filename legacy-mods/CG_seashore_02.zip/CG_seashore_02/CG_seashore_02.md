## CG_seashore 02 - 胸部更改

<video autoplay loop>
  <source src="./CG_seashore_02.mp4" type="video/mp4">
</video>

> 胸部更改(R18)

#MOD #沙滩集会 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG_seashore_02.zip)**