## CG04_SummerRendezvous 07 - 身体更改

<video autoplay loop>
  <source src="./CG04_SummerRendezvous_07.mp4" type="video/mp4">
</video>

> 身体更改(R18)

#MOD #热夏之约 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG04_SummerRendezvous_07.zip)**