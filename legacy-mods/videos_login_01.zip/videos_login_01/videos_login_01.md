## videos_login 01 - 套用第三方视频资源

<video autoplay loop>
  <source src="./videos_login_01.mp4" type="video/mp4">
</video>

> 套用第三方视频资源

via [AhAlpha](http://t.me/ahofcl)

#MOD #视频 #登录界面

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/videos_login_01.zip)**