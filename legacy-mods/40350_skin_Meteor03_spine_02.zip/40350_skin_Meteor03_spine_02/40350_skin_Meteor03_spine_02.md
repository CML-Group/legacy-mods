## 40350_skin_Meteor03_spine 02 - 去除部分衣服

<video autoplay loop>
  <source src="./40350_skin_Meteor03_spine_02.mp4" type="video/mp4">
</video>

> 去除部分衣服

#MOD #星坠 #限定动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/40350_skin_Meteor03_spine_02.zip)**