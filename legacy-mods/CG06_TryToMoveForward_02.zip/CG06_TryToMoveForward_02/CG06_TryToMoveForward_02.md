## CG06_TryToMoveForward 02 - 去除部分衣服 + 衣服破损

<video autoplay loop>
  <source src="./CG06_TryToMoveForward_02.mp4" type="video/mp4">
</video>

> 去除部分衣服 | 衣服破损(R18)

#MOD #导购进修课 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG06_TryToMoveForward_02.zip)**