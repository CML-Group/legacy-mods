## CG03_FireworksLoIent 02 - 去除部分裙子 + 胸部更改

<video autoplay loop>
  <source src="./CG03_FireworksLoIent_02.mp4" type="video/mp4">
</video>

> 去除部分裙子(R18) | 胸部更改(R18)

#MOD #顷刻烟火 #限定插画 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG03_FireworksLoIent_02.zip)**