## 30180_skin03_Machairodus_spine 01 - 去路障

<video autoplay loop>
  <source src="./30180_skin03_Machairodus_spine_01.mp4" type="video/mp4">
</video>

> 去路障

#MOD #刃齿 #限定动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/30180_skin03_Machairodus_spine_01.zip)**