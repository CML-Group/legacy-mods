## 2024_uillean02_draw 01 - 腿部更改

![](./2024_uillean02_draw_01.png)

> 腿部更改(黑丝)

#MOD #乌琳 #突破立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/2024_uillean02_draw_01.zip)**