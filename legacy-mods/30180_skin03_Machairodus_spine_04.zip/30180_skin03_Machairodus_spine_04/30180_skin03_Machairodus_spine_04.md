## 30180_skin03_Machairodus_spine 04 - 去路障 + 身体更改 + 淫纹

<video autoplay loop>
  <source src="./30180_skin03_Machairodus_spine_04.mp4" type="video/mp4">
</video>

> 去路障 | 身体更改(R18) | 淫纹

*相比[上一张](#_30180-skin03-machairodus-spine-03-去路障-淫纹) 淫纹在胸部以及肚脐上方*

#MOD #刃齿 #限定动态立绘 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/30180_skin03_Machairodus_spine_04.zip)**