## 30180_skin03_Machairodus_spine 03 - 去路障 + 淫纹

<video autoplay loop>
  <source src="./30180_skin03_Machairodus_spine_03.mp4" type="video/mp4">
</video>

> 去路障 | 淫纹

#MOD #刃齿 #限定动态立绘

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/30180_skin03_Machairodus_spine_03.zip)**