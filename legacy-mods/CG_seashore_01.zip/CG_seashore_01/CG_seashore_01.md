## CG_seashore 01 - 去除部分衣服 + 去除部分小部件

<video autoplay loop>
  <source src="./CG_seashore_01.mp4" type="video/mp4">
</video>

> 去除部分衣服 | 去除部分小部件

#MOD #沙滩集会 #限定插画

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/CG_seashore_01.zip)**