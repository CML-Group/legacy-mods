## uis_role 01 - 去除部分衣服 + 去除更多衣服 + 半透明衣服 + 胸部更改 + 去和谐 + 衣服更改 + 衣服破损 + 身体更改 + 动画更改 + 身上有字 + 在身上计数 + 淫纹 + 脸红 + 避孕套 + 液体 + 自慰 + 插入物 + 潮吹 + 沉浸快感 + 套用第三方立绘

![](./uis_role_01.png)

> 去除部分衣服 | 去除更多衣服(R18) | 半透明衣服 | 胸部更改(乳环/单乳/R18) | 去和谐(光) | 衣服更改 | 衣服破损 | 身体更改("😅"/R18) | 动画更改(R18) | 身上有字(R18)  | 在身上计数(R18) | 淫纹 | 脸红 | 避孕套 | 液体(酒杯/R18) | 自慰(R18) | 插入物(R18) | 潮吹(R18) | 沉浸快感(R18) | 套用第三方立绘

*"改大头照的"*

*依据[此立绘](../../29_Anthem-Break/animated/#anthem-01-胸部更改)和[此立绘](../../37_Melody-Break/animated/#melody-04-身体更改-胸部更改-动画更改-自慰-潮吹-沉浸快感)和[此立绘](../../24_Arpeggio-Break/animated/#_20110-arpeggio-spine-03-胸部更改)和[此立绘](../../32_Uillean-Break/animated/#_20240-break-uillean-spine-06-胸部更改-腿部更改)和[此立绘](../../31_Talbot-Skin/animated/#_30080-skin-talbot03-spine-03-去除部分衣服-胸部更改-衣服破损-液体-插入物)和[此立绘](../../27_Machairodus-Skin/animated/#_30180-skin03-machairodus-spine-05-去除部分衣服-身体更改-身上有字-在身上计数-插入物-跳蛋)和[此立绘](../../17_Rex-Common/static/#_6002-joyeuse01-draw-01-半透明衣服-身体更改-胸部更改-淫纹-脸红-避孕套)和[此立绘](../../01_Badland-Break/animated/#badlands-02-衣服更改-胸部更改)和[此立绘](../../15_Hurricane-Skin/animated/#_40010-skin-hurricane03-01-去除部分衣服-身体更改)和[此立绘](../../42_Noctilucent-Skin/animated/#_40310-skin-noctilucent03-spine-04-去和谐-去除更多衣服)和[此立绘](../../35_Meteor-Skin/animated/#_40350-skin-meteor03-spine-01-胸部更改)和[此立绘](../../14_Joyeuse-Break/animated/#joyeuse-04-去除部分衣服-胸部更改)和[此立绘](../../45_CG03_FireworksLoIent/animated/#cg03-fireworksloient-03-去除部分裙-胸部更改-身体更改)和[此立绘](../../48_CG06_TryToMoveForward/animated/#cg06-trytomoveforward-04-去除更多衣服-衣服破损-身体更改)和[此立绘](../../legacy/03_Burtgang-Skin/animated/#_60110-skin-burtgang03-02-衣服更改-胸部更改-液体)更改*

artist [剑后席比雅](#暂无此作者的相关链接)

via [琴吹䌷](#暂无此作者的相关链接)

#MOD #圣歌 #琶音 #巴德兰兹 #布尔特根 #随想曲 #卡提那 #杜兰德尔 #飓风 #咎瓦尤斯 #刃齿 #旋律 #星坠 #纳格陵 #荧 #雷克斯 #塔尔博特 #乌琳 #图标 #R18

**获取资源 [Android](https://github.com/CML-Group/legacy-mods/raw/main/legacy-mods/uis_role_01.zip)**